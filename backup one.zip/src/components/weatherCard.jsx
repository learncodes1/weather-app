import React from 'react'
import '../assets/card.css'
const WeatherCard = ({lng,lati}) => {

     return (
 

            <div className="weather-wrapper">
                hello
                <div className="weather-card madrid">
                    <div className="weather-icon sun"></div>
                    <h1>26º</h1>
                    <p>Madrid</p>
                </div>
                <div className="weather-card london">
                    <div className="weather-icon cloud"></div>
                    <h1>14º</h1>
                    <p>London</p>
                </div>
            </div> 
     )
}

export default WeatherCard